/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package NevaAydınHW1;


/**
 *
 * @author Neva AYDIN
 */
public class RollingDice { 
    //this class tests Die and PairOfDice classes
    public static void main(String[] args) {
        Die die=new Die();

        die.roll();
        System.out.println(die.getFaceValue());
        
        PairOfDice pairofdice=new PairOfDice();
        pairofdice.roll();
        System.out.println(die.toString());

    }
    
}
