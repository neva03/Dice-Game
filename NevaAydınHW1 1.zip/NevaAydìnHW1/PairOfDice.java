           /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NevaAydınHW1;

/**
 *
 * @author Neva AYDIN
 */
public class PairOfDice {
    private Die die1;
    private Die die2;

    public PairOfDice() {
        die1 = new Die();
        die2 = new Die();
    }
    
    public Die getDie1(){
        return die1;
    }
    public void setDie1(Die die){
        this.die1=die;
    }
    public Die getDie2(){
        return die2;
    }
    public void setDie2(Die die){
        this.die2=die;
    }
    public String toString(){
        return " rolled "+getDie1().getFaceValue()+ " "+getDie2().getFaceValue();
    }
    public boolean equals(){
        return true;
    }
    public void roll(){ //rolls the dice
        die1.roll();
        die2.roll();
        System.out.println(toString());
    }
    public int getDiceSum(){
        return (getDie1().getFaceValue() + getDie2().getFaceValue());
    }
}
