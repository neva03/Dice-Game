/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NevaAydınHW1;

import java.util.Random;

/**
 *
 * @author Neva AYDIN
 */
public class Die {
    private int faceValue; // the current face value of the die
    public static final int MAX = 6; // the maximum face value of the die
    
    public Die(){
 
    }
    
    public void roll(){
        Random random=new Random();
        faceValue=random.nextInt(1, 7);
        setFaceValue(faceValue);
    }
    public void setFaceValue(int faceValue){
        this.faceValue=faceValue;
    }
    public int getFaceValue(){
        return faceValue;
    }
    public String toString(){
        return "test";
    }
    public boolean equals(){
        return true;
    }
}
