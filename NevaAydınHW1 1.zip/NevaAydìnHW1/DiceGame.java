/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package NevaAydınHW1;

import java.util.Scanner;

/**
 *
 * @author Neva AYDIN
 */
public class DiceGame {

    static String turn;
    static int playerGrandTotal=0; 
    static int compGrandTotal=0;   
    static int playerTurnTotal=0;
    static int compTurnTotal=0;
    static int win=100;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("  Welcome to the DiceGame. It's you against the computer.\n"
                + "You play by rolling the dice. The first player\n"
                + "to get 100 points wins. However, if you roll one 1\n"
                + "you lose all the points you've accumulated in your\n"
                + "turn. If you roll two 1's, you lose all your\n"
                + "points. You can turn the dice over at any time.\n"
                + "However, if you roll one or two 1's, you lose your\n"
                + "turn. I (the computer) play by the same rules,\n"
                + "except I'll always turn over the dice when I've\n"
                + "rolled 20 or more points in a single turn.\n"
                + "Ready to begin? (Type 'y' when you're ready)");
        
        PairOfDice pairofdice = new PairOfDice();


        Scanner scanner = new Scanner(System.in);
        turn = scanner.next(); //takes y or n
        
        if(turn.equals("y")){ 
            playerTurn(); //your turn start
        }

        while(turn.equals("n")){  //if user write "n", computers turn start
            System.out.println("\n"+"I'm rolling the dice . . .");
            System.out.print("I");
            pairofdice.roll();
            if (pairofdice.getDie1().getFaceValue()==1 || pairofdice.getDie2().getFaceValue()==1) { //if computer rolled one 1
                compTurnTotal = 0;
                if(pairofdice.getDie1().getFaceValue()==1 && pairofdice.getDie2().getFaceValue()==1){ //if computer rolled 1 1 
                    System.out.println("I got two 1's!");
                    compGrandTotal=0;
                }else{
                    System.out.println("I got a 1!");
                }
                System.out.println("Continue? (Type 'y' when you're ready to\n"
                        + " turn the dice over to me)");
                turn = scanner.next();
                System.out.println("The score is");
                System.out.println("    You:       "+playerGrandTotal);
                System.out.println("    Computer:  "+compGrandTotal);
                playerTurn();
            }
            else {
                System.out.println("This gives me a turn total of ");

                compTurnTotal += pairofdice.getDiceSum();
                System.out.println(compTurnTotal);
                System.out.println("and a grand total of");
                compGrandTotal += pairofdice.getDiceSum();
                System.out.println(compGrandTotal);
                if (compGrandTotal >= win) {
                    System.out.println("Better luck next time");
                    System.exit(0);
                }
            }
            if(compTurnTotal>=20){
                System.out.println("Continue? (Type 'y' when you're ready to\n"
                        + " turn the dice over to me)");
                turn = scanner.next();
                System.out.println("The score is");
                System.out.println("    You:       "+playerGrandTotal);
                System.out.println("    Computer:  "+compGrandTotal);
                compTurnTotal=0;
                playerTurn();
            }
        }  
    }
    
    public static void playerTurn(){
        
        Scanner scanner = new Scanner(System.in);  
        PairOfDice pairofdice = new PairOfDice();
        
        while (turn.equals("y")) {
            System.out.println("\n" +"You're rolling the dice . . .");
            System.out.print("You");
            pairofdice.roll();
           
            if (pairofdice.getDie1().getFaceValue()==1 || pairofdice.getDie2().getFaceValue()==1) { //if you rolled one 1
                playerTurnTotal = 0;
                if(pairofdice.getDie1().getFaceValue()==1 && pairofdice.getDie2().getFaceValue()==1){ //if you rolled 1 1 
                    System.out.println("You got two 1's!");
                    playerGrandTotal=0;
                }else{
                    System.out.println("You got a 1!");
                }
                System.out.println("Continue? (Type 'y' when you're ready to\n"
                        + " turn the dice over to me)");
                turn = scanner.next();
                System.out.println("The score is");
                System.out.println("    You:       "+playerGrandTotal);
                System.out.println("    Computer:  "+compGrandTotal);
                turn="n";
            }
            else {

                System.out.println("This gives you a turn total of");
                playerTurnTotal+=pairofdice.getDiceSum();

                System.out.println(playerTurnTotal);

                playerGrandTotal += pairofdice.getDiceSum();

                System.out.println("and a grand total of");
                System.out.println(playerGrandTotal);
                
                if (playerGrandTotal >= win) {
                    System.out.println("congratulations, you win");
                    System.exit(0);
                }
                System.out.println("The computer has a total of");
                System.out.println(compGrandTotal);
                System.out.println("Do you want to continue rolling? (Type 'y' or 'n')");
                turn = scanner.next();               
                if(turn.equals("n")){
                    playerTurnTotal=0;
                }
            }
        }
    }
}
